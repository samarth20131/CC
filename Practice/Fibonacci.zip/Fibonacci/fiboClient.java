import java.rmi.*;
import java.rmi.server.*;


public class fiboClient 
{
    public static void main(String[] args) {
        try {
            System.out.println("Security Manager Loaded");
            String url = "//localhost/FIBO-SERVER";

            fiboServer remoteObject = (fiboServer)Naming.lookup(url);

            
            System.out.println("Got remote object");
            System.out.print("\n");
            System.out.print("Fibonaacci Series : ");
            int a = Integer.parseInt(args[0]);
            for(int i=0;i<a;i++){
                System.out.print(remoteObject.fibo(i) + " ");
            }
            System.out.println("\n");
            String str = (args[1]);
            if(remoteObject.palin(str) != null){
                System.out.println("Entered Stirng is Palindrome");
            }
            else{
                System.out.println("Entered Stirng is Not Palindrome");
            }

            System.out.print("\n");
            int p = Integer.parseInt(args[2]);
            System.out.println("Factorial of " + p + " is : " + remoteObject.factorial(p));

        }
        catch(RemoteException re){
            System.out.println("RemoteException: " + re.toString());
        }
        catch(java.net.MalformedURLException ex){
            System.out.println("MalformedURLException: " + ex.toString());
        }
        catch(java.rmi.NotBoundException exc){
            System.out.println("NotBoundException: " + exc.toString());
        }
    }
}